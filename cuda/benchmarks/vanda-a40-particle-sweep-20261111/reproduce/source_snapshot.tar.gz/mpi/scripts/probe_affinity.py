#!/usr/bin/env python3
"""Record MPI rank affinity or verify distinct physical cores and planned hosts."""
import argparse
from collections import Counter
import csv
import json
import os
from pathlib import Path
import socket


def hostname(value):
    return value.lower().split(".")[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", type=Path)
    parser.add_argument("--ranks", type=int)
    parser.add_argument("--layout", type=Path)
    args = parser.parse_args()
    if args.check:
        if not args.ranks or not args.layout:
            parser.error("--check needs --ranks and --layout")
        data = [json.loads(line) for line in args.check.read_text().splitlines() if line.strip()]
        with args.layout.open(newline="") as stream:
            layout = {hostname(h): int(n) for h, n in csv.reader(stream, delimiter="\t")}
        if len(data) != args.ranks or sorted(row["rank"] for row in data) != list(range(args.ranks)):
            raise RuntimeError("missing or duplicate MPI rank affinity records")
        if Counter(hostname(row["host"]) for row in data) != Counter(layout):
            raise RuntimeError("actual host counts differ from the planned MPI layout")
        cores = set()
        for row in data:
            if len(row["physical_cores"]) != 1:
                raise RuntimeError(f"rank {row['rank']} is not restricted to one physical core")
            key = (hostname(row["host"]), *row["physical_cores"][0])
            if key in cores:
                raise RuntimeError("MPI ranks share a physical CPU core")
            cores.add(key)
        print(f"PASS: {args.ranks} ranks use distinct physical cores on {len(layout)} planned hosts.")
        return
    cpus = sorted(os.sched_getaffinity(0))
    physical = set()
    for cpu in cpus:
        root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        physical.add((int((root / "physical_package_id").read_text()),
                      int((root / "core_id").read_text())))
    print(json.dumps({"rank": int(os.environ["OMPI_COMM_WORLD_RANK"]),
                      "host": hostname(socket.gethostname()), "logical_cpus": cpus,
                      "physical_cores": sorted(physical)}), flush=True)


if __name__ == "__main__":
    main()
