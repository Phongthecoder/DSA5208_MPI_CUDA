#!/bin/bash
set -euo pipefail
usage() {
    cat <<'EOF'
Usage: submit_vanda_platinum.sh --hosts FILE --project CODE [--dry-run]
                                [--validate-only] [RANKS ...]

FILE is a tab-separated table with header host,node_pool,cpu_model.
Every host must first pass the Platinum 8452Y CPU probe. Defaults:
1 2 4 8 16 32 64 128 256. For 64/128/256, use 2/4/8 hosts x32 ranks.
Baseline jobs use separate hosts; larger jobs wait for the baselines and
run sequentially. The runtime worker checks actual CPUs, hosts and cores.
EOF
}
project="${PBS_PROJECT:-}"
hosts_file=""
dry_run=0
validate_only=0
requested=()
while (( $# )); do
    case "$1" in
        --hosts|--project)
            (( $# >= 2 )) || { usage >&2; exit 2; }
            key="$1"; shift
            if [[ "$key" == --hosts ]]; then hosts_file="$1"; else project="$1"; fi
            ;;
        --dry-run) dry_run=1 ;;
        --validate-only) validate_only=1 ;;
        -h|--help) usage; exit 0 ;;
        -*) usage >&2; exit 2 ;;
        *) requested+=("$1") ;;
    esac
    shift
done
if [[ ! "$project" =~ ^[a-zA-Z0-9_.-]+$ ]] || [[ ! -r "$hosts_file" ]]; then
    printf 'A project code and a readable, CPU-qualified host table are required.\n' >&2
    exit 2
fi
hosts_file="$(cd "$(dirname "$hosts_file")" && pwd -P)/$(basename "$hosts_file")"
if ! awk -F '\t' '
    NR == 1 {if ($1 != "host" || $2 != "node_pool" || $3 != "cpu_model") bad=1; next}
    NF != 3 || $1 !~ /^[a-z0-9][a-z0-9-]*$/ || $2 !~ /^cpu_(node|free)$/ ||
      $3 != "Intel(R) Xeon(R) Platinum 8452Y" || seen[$1]++ {bad=1}
    END {exit (bad || NR < 2)}
' "$hosts_file"; then
    printf 'Invalid Platinum host table: %s\n' "$hosts_file" >&2; exit 2
fi
hosts=(); pools=()
while IFS=$'\t' read -r host pool model; do
    [[ "$host" == host ]] && continue
    hosts+=("$host"); pools+=("$pool")
done < "$hosts_file"
if (( ${#requested[@]} == 0 )); then requested=(1 2 4 8 16 32 64 128 256); fi
layouts=(); specs=(); node_counts=(); host_lists=()
seen=" "
for ranks in "${requested[@]}"; do
    if [[ ! "$ranks" =~ ^[1-9][0-9]{0,2}$ ]] || (( ranks > 256 || (ranks & (ranks - 1)) != 0 )) ||
       [[ "$seen" == *" $ranks "* ]]; then
        printf 'Ranks must be distinct powers of two up to 256: %s\n' "$ranks" >&2; exit 2
    fi
    seen+="$ranks "
    if (( ranks <= 32 )); then
        index=0; value="$ranks"
        while (( value > 1 )); do index=$((index+1)); value=$((value/2)); done
        indices=("$index"); slots="$ranks"
    else
        indices=(); slots=32
        for (( index=0; index<ranks/32; index++ )); do indices+=("$index"); done
    fi
    layout=""; chunks=(); selected_hosts=()
    for index in "${indices[@]}"; do
        if (( index >= ${#hosts[@]} )); then
            printf 'Not enough qualified hosts for %s ranks.\n' "$ranks" >&2; exit 2
        fi
        host="${hosts[index]}"; pool="${pools[index]}"
        layout+="$host"$'\t'"$slots"$'\n'
        chunks+=("1:ncpus=$slots:mpiprocs=$slots:ompthreads=1:mem=$((7*slots))gb:node_pool=$pool:host=$host")
        selected_hosts+=("$host")
    done
    layouts+=("$layout")
    specs+=("$(IFS=+; printf '%s' "${chunks[*]}")")
    node_counts+=("${#indices[@]}")
    host_lists+=("$(IFS=+; printf '%s' "${selected_hosts[*]}")")
done
cd "$(dirname "${BASH_SOURCE[0]}")/.."
print_plan() {
    printf 'ranks\tnodes\tselect\n'
    for i in "${!requested[@]}"; do
        printf '%s\t%s\t%s\n' "${requested[i]}" "${node_counts[i]}" "${specs[i]}"
    done
}
if (( dry_run )); then print_plan; exit 0; fi
qstat -B >/dev/null
qstat -Q auto >/dev/null
mkdir -p results
submission="$(mktemp -d "$PWD/results/vanda-platinum-submit.XXXXXXXX")"
relative="results/${submission##*/}"
cp "$hosts_file" "$submission/qualified_hosts.tsv"
printf 'Intel(R) Xeon(R) Platinum 8452Y\n' > "$submission/expected_cpu_model.txt"
print_plan > "$submission/plan.tsv"
printf 'Submission records: %s\n' "$submission" >&2
printf 'ranks,nodes,job_id,hosts,submit_queue,dependency\n' | tee "$submission/jobs.csv"
baselines=()
previous_multi=""
for i in "${!requested[@]}"; do
    ranks="${requested[i]}"
    layout="$relative/p$ranks.layout.tsv"
    printf '%s' "${layouts[i]}" > "$layout"
    dependency=""
    if (( ranks > 32 )); then
        if [[ -n "$previous_multi" ]]; then dependency="$previous_multi"
        elif (( ${#baselines[@]} )); then dependency="$(IFS=:; printf '%s' "${baselines[*]}")"
        fi
    fi
    args=(-q auto -P "$project" -N "dsa5208_pl_p$ranks" -l "select=${specs[i]}" -l place=scatter
          -l walltime=00:45:00 -o "$submission/p$ranks.log"
          -v "MPI_RANKS=$ranks,MPI_LAYOUT=$layout,MPI_CPU_MODEL_FILE=$relative/expected_cpu_model.txt,MPI_VALIDATE_ONLY=$validate_only")
    [[ -z "$dependency" ]] || args+=(-W "depend=afterok:$dependency")
    job="$(qsub "${args[@]}" scripts/vanda_mpi.pbs)"
    printf '%s,%s,%s,%s,auto,%s\n' "$ranks" "${node_counts[i]}" "$job" "${host_lists[i]}" "$dependency" |
        tee -a "$submission/jobs.csv"
    if (( ranks <= 32 )); then baselines+=("$job"); else previous_multi="$job"; fi
done
